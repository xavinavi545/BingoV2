package BingoG;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class VentanaNumeros extends JFrame {

    JPanel panel_principal;
    static JLabel numero = new JLabel("");

    public VentanaNumeros() {
       
        setTitle("");
        setBounds(450, 0, 80, 100);
        setResizable(false);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        visible();
        setVisible(true);
    }

    void visible() {    
        panel_principal = new JPanel();
        numero.setBounds(0, 0, 80, 100);
        numero.setText("");
        numero.setFont(new Font(Font.SERIF, Font.BOLD, 50));
        numero.setHorizontalAlignment(JLabel.CENTER);
        numero.setForeground(Color.BLUE);
        numero.setBackground(Color.getHSBColor(48, 62, 115));
        panel_principal.setBackground(Color.getHSBColor(48, 62, 115));
        numero.setOpaque(true);
        panel_principal.add(numero);
        getContentPane().add(panel_principal);
    }

    public static void main(String[] args) {
        VentanaNumeros v = new VentanaNumeros();

    }

}