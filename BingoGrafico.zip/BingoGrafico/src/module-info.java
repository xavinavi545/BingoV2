module BingoGrafico {
	requires java.desktop;
}